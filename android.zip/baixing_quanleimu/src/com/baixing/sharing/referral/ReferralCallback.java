package com.baixing.sharing.referral;

import android.content.Intent;

public interface ReferralCallback {
	
	public abstract void doAction(Intent intent);
	
}
