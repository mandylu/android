//liuchong@baixing.com
package com.baixing.broadcast;

/**
 * 
 * @author liuchong
 *
 */
public interface NotificationIds {
	int NOTIFICATION_ID_CHAT_MESSAGE = 1001;
	int NOTIFICATION_XMPP_CONNECTION_STATUS = 2001;
	int NOTIFICATION_ID_BXINFO = 3001;
	int NOTIFICATION_ID_UPGRADE = 4001;
	int NOTIFICATION_ID_JUMPURL = 5001;
    int NOTIFICATION_ID_DEBUG = 6001;
}
