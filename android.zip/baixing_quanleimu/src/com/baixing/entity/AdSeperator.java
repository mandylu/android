package com.baixing.entity;

public class AdSeperator extends Ad{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4710486029537765113L;
	
}