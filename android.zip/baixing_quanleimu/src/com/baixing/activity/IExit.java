package com.baixing.activity;

public interface IExit {
	public void handleFragmentAction();
}
