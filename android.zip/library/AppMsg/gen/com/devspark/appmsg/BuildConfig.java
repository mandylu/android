/** Automatically generated file. DO NOT MODIFY */
package com.devspark.appmsg;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}