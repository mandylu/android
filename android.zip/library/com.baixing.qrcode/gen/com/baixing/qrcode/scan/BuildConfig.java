/** Automatically generated file. DO NOT MODIFY */
package com.baixing.qrcode.scan;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}